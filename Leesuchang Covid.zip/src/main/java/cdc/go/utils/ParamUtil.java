package cdc.go.utils;

public class ParamUtil {
	public String encode(String params) {
		return "Encoded!!" + params;
	}
}
